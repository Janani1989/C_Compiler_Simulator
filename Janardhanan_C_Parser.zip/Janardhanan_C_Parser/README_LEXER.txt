The python program Lexer.py removes valid comments conforming to C Language specification.On the other hand,it also reports the incorrect or erroneous comments found in the input file provided by user.

*The program removes all valid comments and writes the new content to a file called "withoutcomments.txt'
*Errors are also detected to a good extent and reported on console discriminating if its an improperly terminated /* comment or invalid// comment
*Regular Expressions and Text processing are exclusively used to perform these tasks

REGEX FUNCTIONS USED:

compile()- Pattern Matching for future use
sub()- Substitue a pattern with replacement pattern on a string
findall()- Finds all the occurences of a given pattern
search()- Finds the first occurence of a pattern in a given string

STRING FUNCTIONS USED:

replace() - exchange a old substring with a new substring on a string
strip()- Remove whitespaces from a string
startswith()- Check if a string starts with a particular substring
endswith()- Check if a string ends with a particular substring