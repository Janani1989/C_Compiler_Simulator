/* Recursive descent parser for the calculator language (Figure 2.15 and 2.16).
*/

#include <stdio.h>
#include <stdlib.h>	// We included this header as exit() was unrecognized
struct syntax_tree{
char* node;
struct syntax_tree *child[5];
int child_count;
};

typedef enum {read, write, id, literal, becomes,
                add, sub, mul, division, lparen, rparen, eof, lno} token; //included lno

extern char token_image[];
extern int lnum;

char* names[] = {"read", "write", "id", "literal", "becomes",
                "add", "sub", "mul", "division", "lparen", "rparen", "eof", "L.NO"}; //included L.NO

static token input_token;
int error_found=0;
void error(char* expected,int lnum) { //signature changed
	error_found++;
	if((strcmp(expected,"read")==0)|| (strcmp(expected,"write")==0))
	printf("Syntax error: Invalid instruction : use read/write\n");
	else if(strcmp(expected,"becomes")==0)
	printf("Syntax error: Variable on line number %d should be defined using :=\n",lnum);
	else if(strcmp(expected,"lparen")==0 || strcmp(expected,"rparen")==0)
	printf("syntax error: Missing %s on line number %d\n",expected,lnum); // changed code
	else
	printf("Syntax error: %s with current token as %s on line number %d\n",expected,names[input_token],lnum);
    
   exit(1);
}

void match(token expected) {
    if (input_token == expected) {
        printf("matched %s", names[input_token]);
        if (input_token == id || input_token == literal)
            printf(": %s", token_image);
	printf("\n");
        input_token = scan();
	
         if(input_token==lno){
	
	printf("Processing line number %d \n",lnum);
	 input_token = scan();
	
	}
    }
    else{
	printf("called for the token %s\n",names[input_token]);
	 error(names[expected],lnum);
	}
}

void program();
void stmt_list();
void stmt();
void expr();
void term_tail();
void term();
void factor_tail();
void factor();
void add_op();
void mult_op();

void program(struct syntax_tree *tree) {
    printf("predict program\n");
int childcount=0;
	tree->child[childcount]=(struct syntax_tree *)malloc(sizeof (struct syntax_tree));
	tree->child[childcount++]->node="stmt_list";
	tree->child[childcount]=(struct syntax_tree *)malloc(sizeof (struct syntax_tree));
	tree->child[childcount]->node="$$";
	tree->child_count=childcount;
    switch (input_token) {
        case id:
        case read:
        case write:
        case eof:
            stmt_list(tree->child[0]);
            match(eof);
            break;
        default: error("Invalid statement",lnum);
		printf("error called from program\n");
    }
}

void stmt_list(struct syntax_tree *tree) {
	int childcount=0;
if(tree==NULL){
printf("null val\n");
exit(1);
}	
    printf("predict stmt_list\n");
    switch (input_token) {
        case id: 
        case read:
        case write:
	tree->child[childcount]=(struct syntax_tree *)malloc(sizeof (struct syntax_tree));
	tree->child[childcount++]->node="stmt";
	stmt(tree->child[0]);
	tree->child[1]=(struct syntax_tree *)malloc(sizeof (struct syntax_tree));
	tree->child[1]->node="stmt_list";
        stmt_list(tree->child[1]);
        break;
        case eof: printf("eof");
		tree->child[0]=(struct syntax_tree *)malloc(sizeof (struct syntax_tree));
		tree->child[0]->node="epsilon";
            break;          /*  epsilon production */
        default: error("Invalid statement",lnum);
printf("error called from stmt_list\n");
    }
tree->child_count=childcount;
}

void stmt(struct syntax_tree *tree) {
int childcount=0;
tree->child[0]=(struct syntax_tree *)malloc(sizeof (struct syntax_tree));
tree->child[1]=(struct syntax_tree *)malloc(sizeof (struct syntax_tree));
printf("predict stmt\n");
	switch(input_token){
		case id:
		tree->child[0]->node="id"; 
			match(id);
		tree->child[1]->node=":=";
			match(becomes);
		tree->child[2]=(struct syntax_tree *)malloc(sizeof (struct syntax_tree));
		tree->child[2]->node="expr";
			expr(tree->child[2]);
		childcount=2;
			break;
		case read:
		tree->child[childcount++]->node="read";
			match(read);
		tree->child[childcount]->node="id";
			match(id);
			break;
		case write:
		tree->child[childcount++]->node="write";
			match(write);
		tree->child[childcount]->node="expr";
			expr(tree->child[childcount]);
			break;
		default: error("Invalid statement",lnum);
	printf("error called from stmt\n");
			
	}
tree->child_count=childcount;
}

void expr(struct syntax_tree *tree) {
int childcount=0;
tree->child[0]=(struct syntax_tree *)malloc(sizeof (struct syntax_tree));
tree->child[1]=(struct syntax_tree *)malloc(sizeof (struct syntax_tree));
printf("predict expr\n");
	switch(input_token){
		case id:
		case literal:
		case lparen:
		tree->child[childcount++]->node="term";
			term(tree->child[0]);
		tree->child[childcount]->node="term_tail";
			term_tail(tree->child[childcount]);
			break;
		default: error("Invalid expression",lnum);
printf("error called from expr\n");
			
	}
tree->child_count=childcount;
}

void term_tail(struct syntax_tree *tree) {
	int childcount=0;
    printf("predict term_tail\n");
if(tree==NULL){
printf("null val in term_tail\n");
exit(1);
}
tree->child[childcount]=(struct syntax_tree *)malloc(sizeof (struct syntax_tree));
    switch (input_token) {
        case add:
        case sub:
	tree->child[childcount++]->node="add_op";
            add_op(tree->child[0]);
	tree->child[childcount]=(struct syntax_tree *)malloc(sizeof (struct syntax_tree));
	tree->child[childcount++]->node="term";
            term(tree->child[1]);
	tree->child[childcount]=(struct syntax_tree *)malloc(sizeof (struct syntax_tree));
	tree->child[childcount]->node="term_tail";
            term_tail(tree->child[childcount]);
            break;
        case rparen:
        case id:
        case read:
        case write:
        case eof: tree->child[childcount]->node="epsilon";
            break;          /*  epsilon production */
        default: error("Invalid  expression",lnum);
printf("error called from term_tail\n");
    }
tree->child_count=childcount;
}

void term(struct syntax_tree *tree) {
	int childcount=0;
	printf("predict term\n");
	tree->child[0]=(struct syntax_tree *)malloc(sizeof (struct syntax_tree));
	tree->child[1]=(struct syntax_tree *)malloc(sizeof (struct syntax_tree));
	switch(input_token){
		case id:
		case literal:
		case lparen:
		tree->child[childcount++]->node="factor";
			factor(tree->child[0]);
		tree->child[childcount]->node="factor_tail";
			factor_tail(tree->child[1]);
			break;
		default: error("Invalid expression",lnum);
printf("error called from term\n");
			
	}
tree->child_count=childcount;

}

void factor_tail(struct syntax_tree *tree) {
    printf("predict factor_tail\n");
if(tree==NULL){
printf("null val in factor_tail\n");
exit(1);
}
	int childcount=0;
tree->child[childcount]=(struct syntax_tree *)malloc(sizeof (struct syntax_tree));
    switch (input_token) {
        case mul:
        case division:
	tree->child[childcount++]->node="mult_op";
            mult_op(tree->child[0]);
	tree->child[childcount]=(struct syntax_tree *)malloc(sizeof (struct syntax_tree));
	tree->child[childcount++]->node="factor";
            factor(tree->child[1]);
	tree->child[childcount]=(struct syntax_tree *)malloc(sizeof (struct syntax_tree));
	tree->child[childcount]->node="factor_tail";
            factor_tail(tree->child[childcount]);
            break;
        case add:
        case sub:
        case rparen:
        case id:
        case read:
        case write:
        case eof:tree->child[childcount]->node="epsilon";
            break;          /*  epsilon production */
        default: error("Invalid expression",lnum);
printf("error called from factor_tail\n");
    }
tree->child_count=childcount;
}

void factor(struct syntax_tree *tree) {
printf("predict factor\n");
int childcount=0;
tree->child[childcount]=(struct syntax_tree *)malloc(sizeof (struct syntax_tree));
switch (input_token) {
	case id :
	tree->child[childcount]->node="id";
	 	match(id);
		break;
	case literal:
	tree->child[childcount]->node="literal";
		match(literal);
		break;
	case lparen:
	tree->child[childcount++]->node="(";
		match(lparen);
	tree->child[childcount]=(struct syntax_tree *)malloc(sizeof (struct syntax_tree));
	tree->child[childcount++]->node="expr";
		expr(tree->child[1]);
	tree->child[childcount]=(struct syntax_tree *)malloc(sizeof (struct syntax_tree));
	tree->child[childcount]->node=")";
		match(rparen);
		break;
	default: error("Invalid expression",lnum);
printf("error called from factor\n");

	}
tree->child_count=childcount;
}

void add_op(struct syntax_tree *tree) {
    printf("predict add_op\n");
	int childcount=0;
	tree->child[childcount]=(struct syntax_tree *)malloc(sizeof (struct syntax_tree));
    switch (input_token) {
        case add:
	tree->child[childcount]->node="+";
            match(add);
            break;
        case sub:
	tree->child[childcount]->node="-";
            match(sub);
            break;
        default: error("Invalid Arithmetic Operation : Use +/-",lnum);
printf("error called from add_op\n");
    }
tree->child_count=childcount;
}

void mult_op(struct syntax_tree *tree) {
    printf("predict mult_op\n");
	int childcount=0;
	tree->child[childcount]=(struct syntax_tree *)malloc(sizeof (struct syntax_tree));
    switch (input_token) {
        case mul:
	tree->child[childcount]->node="*";
            match(mul);
            break;
        case division:
	tree->child[childcount]->node="/";
            match(division);
            break;
        default: error("Invalid Arithmetic Operation : Use *//",lnum);
printf("error called from mult_op\n");
    }
tree->child_count=childcount;
}
void preorder(struct syntax_tree *tree){
int i;
	if(tree!=NULL){
	printf("%s ",tree->node);
	for(i=0;i<=tree->child_count;i++){
	preorder(tree->child[i]);
	}
	printf("\n");
	}
}
int main() {
	struct syntax_tree *root=(struct syntax_tree *)malloc(sizeof(struct syntax_tree));
    input_token = scan();
if(input_token==lno){
	printf("Processing line number %d ",lnum);	
	 input_token = scan();
	}
    root->node="program";
	struct syntax_tree *tree=root;
    program(tree);
    if(error_found==0){
	printf("\nCorrect syntax!!!!!!!!!!\n");
	printf("\n******************Extra-credit part******************\n\n");
	printf("****************************Syntax Tree Traversal********************\n");
	if(root!=NULL)
	preorder(root);	

	}
   
}
